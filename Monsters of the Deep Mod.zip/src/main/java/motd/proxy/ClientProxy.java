package motd.proxy;

public class ClientProxy implements IProxy {
	
	@Override
	public void preInit() {
		
	}
	
	@Override
	public void init() {
		
	}
	
	@Override
	public void postInit() {
		
	}
	
}
