package motd;

public class References {
	
	public static final String MODID = "motd";
	public static final String NAME = "Monsters of the Deep";
	public static final String VERSION = "ALPHA 1.0";
	
	public static final String CLIENT_PROXY_PATH = "motd.proxy.ClientProxy";
	public static final String SERVER_PROXY_PATH = "motd.proxy.ServerProxy";
	
}
